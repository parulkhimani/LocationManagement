<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('JPATH_BASE') or die;

JFormHelper::loadFieldClass('list');

require_once __DIR__ . '/../../helpers/locationmanagement.php';

/**
 * Bannerclient Field class for the Joomla Framework.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 * @since       1.6
 */
class JFormFieldStates extends JFormFieldList
{
	/**
	 * The form field type.
	 *
	 * @var		string
	 * @since   1.6
	 */
	protected $type = 'States';

	/**
	 * Method to get the field options.
	 *
	 * @return  array  The field option objects.
	 *
	 * @since   1.6
	 */
	public function getOptions()
	{
		$countryid = "";
		$formData = JRequest::getVar('filter', array(), 'post', 'array');
	
		if($this->form->getValue('countryid')|| (isset($formData['countryid']) && $formData['countryid'] > 0) || (isset($this->form->getValue('filter')->countryid) && $this->form->getValue('filter')->countryid >0))
		{
			if($this->form->getValue('countryid'))
			{	
				$countryid=$this->form->getValue('countryid');
			}
			else if($this->form->getValue('filter')->countryid)
			{
				$countryid=$this->form->getValue('filter')->countryid;
			}
			else
			{
				$countryid=$formData['countryid'];
			}
		}
		
		$options = LocationmanagementHelper::getStatesOptions($countryid);
		return array_merge(parent::getOptions(), $options);
	}
}
