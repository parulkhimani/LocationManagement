DROP TABLE IF EXISTS `#__country`;
DROP TABLE IF EXISTS `#__state`;
DROP TABLE IF EXISTS `#__city`;
