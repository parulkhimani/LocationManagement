<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

defined('_JEXEC') or die;

/**
 * Banner table
 *
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 * @since       1.5
 */
class LocationmanagementTableCity extends JTable
{
	/**
	 * Constructor
	 *
	 * @param   JDatabaseDriver  &$_db  Database connector object
	 *
	 * @since   1.5
	 */
	public function __construct(&$_db)
	{
		parent::__construct('#__city', 'id', $_db);

		$date = JFactory::getDate();
		$this->created = $date->toSql();
	}

	
	/**
	 * Overloaded check function
	 *
	 * @return  boolean
	 *
	 * @see     JTable::check
	 * @since   1.5
	 */
	public function check()
	{
		if(empty($this->id) || $this->id == 0)
		{
			$checkuniquename = $this->getUniqueName($this->name,$this->stateid,$this->countryid);
			if($checkuniquename > 0)
			{
				$this->setError(JText::_('COM_LOCATIONMANAGEMENT_ALL_READY_USED'));
				return false;
			}
		}
		else
		{
			$fieldname = $this->getFieldName($this->id);
			if($fieldname != $this->name)
			{
				$checkuniquename = $this->getUniqueName($this->name,$this->stateid,$this->countryid,$this->id);
				if($checkuniquename > 0)
				{
					$this->setError(JText::_('COM_LOCATIONMANAGEMENT_ALL_READY_USED'));
					return false;
				}
			}
		}
		
		return true;
	}

	/**
	 * Overloaded bind function
	 *
	 * @param   array  $array   Named array to bind
	 * @param   mixed  $ignore  An optional array or space separated list of properties to ignore while binding.
	 *
	 * @return  mixed  Null if operation was satisfactory, otherwise returns an error
	 *
	 * @since   1.5
	 */
	public function bind($array, $ignore = array())
	{
		
		return parent::bind($array, $ignore);
	}

	/**
	 * Method to store a row
	 *
	 * @param   boolean  $updateNulls  True to update fields even if they are null.
	 *
	 * @return  boolean  True on success, false on failure.
	 */
	public function store($updateNulls = false)
	{
		$user = JFactory::getUser();
		if (empty($this->id))
		{
			$this->createdby = $user->id;
			// Store the row
			parent::store($updateNulls);
		}
		else
		{
			// Get the old row
			$oldrow = JTable::getInstance('Country', 'LocationmanagementTable');

			if (!$oldrow->load($this->id) && $oldrow->getError())
			{
				$this->setError($oldrow->getError());
			}

			
			// Store the new row
			parent::store($updateNulls);

		}

		return count($this->getErrors()) == 0;
	}

	/**
	 * Method to set the publishing state for a row or list of rows in the database
	 * table.  The method respects checked out rows by other users and will attempt
	 * to checkin rows that it can after adjustments are made.
	 *
	 * @param   mixed    $pks     An optional array of primary key values to update.  If not set the instance property value is used.
	 * @param   integer  $state   The publishing state. eg. [0 = unpublished, 1 = published, 2=archived, -2=trashed]
	 * @param   integer  $userId  The user id of the user performing the operation.
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   1.6
	 */
	public function publish($pks = null, $state = 1, $userId = 0)
	{
		$k = $this->_tbl_key;

		// Sanitize input.
		JArrayHelper::toInteger($pks);
		$userId = (int) $userId;
		$state = (int) $state;

		// If there are no primary keys set check to see if the instance key is set.
		if (empty($pks))
		{
			if ($this->$k)
			{
				$pks = array($this->$k);
			}
			// Nothing to set publishing state on, return false.
			else
			{
				$this->setError(JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));

				return false;
			}
		}

		// Get an instance of the table
		$table = JTable::getInstance('City', 'LocationmanagementTable');

		// For all keys
		foreach ($pks as $pk)
		{
			// Load the banner
			if (!$table->load($pk))
			{
				$this->setError($table->getError());
			}

			// Change the state
			$table->state = $state;
			
			// Check the row
			$table->check();

			// Store the row
			if (!$table->store())
			{
				$this->setError($table->getError());
			}
			
		}

		return count($this->getErrors()) == 0;
	}

	public function getUniqueName($name,$stateid,$countryid,$cityid="")
	{
		$condition = "";
		if($cityid != "" && $cityid > 0)
		{
			$condition = " and a.id != ".$cityid;
		}
		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
			->select('count(a.id) as tot')
			->from('#__city AS a')
			->where('a.name ="'.$name.'"')
			->where('a.stateid ="'.$stateid.'"')
			->where('a.countryid ="'.$countryid.'"'.$condition);
		// Get the options.
		$db->setQuery($query);
		$data = $db->loadObjectList();
		return $data[0]->tot;
	}
	public function getFieldName($id)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
			->select('a.name')
			->from('#__city AS a')
			->where('a.id ='.$id);
		// Get the options.
		$db->setQuery($query);
		$data = $db->loadObjectList();
		return $data[0]->name;
	}
	
	
}
