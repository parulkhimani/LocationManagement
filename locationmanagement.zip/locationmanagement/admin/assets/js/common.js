// JavaScript Document
function getState(id)
{
	jQuery.ajax({
		  type: "GET",
		  url: "index.php?option=com_locationmanagement&task=ajax.getState&id="+id,
		  success: function(html)
			{
				jQuery("#jform_stateid").html(html);
			}
		 });
}

function getCity(id)
{
	jQuery.ajax({
		  type: "GET",
		  url: "index.php?option=com_locationmanagement&task=ajax.getCity&id="+id,
		  success: function(html)
			{
				jQuery("#jform_cityid").html(html);
			}
		 });
}
