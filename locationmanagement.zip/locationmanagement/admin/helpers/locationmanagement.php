<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Banners component helper.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 * @since       1.6
 */
class LocationmanagementHelper extends JHelperContent
{
	/**
	 * Configure the Linkbar.
	 *
	 * @param   string  $vName  The name of the active view.
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	public static function addSubmenu($vName)
	{
		JHtmlSidebar::addEntry(
			JText::_('COM_LOCATIONMANAGEMENT_SUBMENU_COUNTRIES'),
			'index.php?option=com_locationmanagement&view=countries',
			$vName == 'countries'
		);
		
		JHtmlSidebar::addEntry(
			JText::_('COM_LOCATIONMANAGEMENT_SUBMENU_STATES'),
			'index.php?option=com_locationmanagement&view=states',
			$vName == 'states'
		);
	
		JHtmlSidebar::addEntry(
			JText::_('COM_LOCATIONMANAGEMENT_SUBMENU_CITIES'),
			'index.php?option=com_locationmanagement&view=cities',
			$vName == 'cities'
		);
		
	}


	/**
	 * Get Countries list in text/value format for a select field
	 *
	 * @return  array
	 */
	public static function getCountriesOptions()
	{
		$options = array();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
			->select('id As value, name As text')
			->from('#__country AS a')
			->where('a.state = 1')
			->order('a.name ASC');

		// Get the options.
		$db->setQuery($query);

		try
		{
			$options = $db->loadObjectList();
		}
		catch (RuntimeException $e)
		{
			JError::raiseWarning(500, $e->getMessage());
		}

		// Merge any additional options in the XML definition.
		// $options = array_merge(parent::getOptions(), $options);

		array_unshift($options, JHtml::_('select.option', '', JText::_('COM_LOCATIONMANAGEMENT_NO_COUNTRY')));

		return $options;
	}
	
	/**
	 * Get Countries list in text/value format for a select field
	 *
	 * @return  array
	 */

	

	//get Country Name
	public static function getCountryName($id)
	{
		$options = array();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
			->select('a.id,a.name,a.shortname')
			->from('#__country AS a')
			->where('a.state = 1')
			->where('a.id ='.$id);

		// Get the options.
		$db->setQuery($query);

		try
		{
			$options = $db->loadObjectList();
		}
		catch (RuntimeException $e)
		{
			JError::raiseWarning(500, $e->getMessage());
		}
		return $options[0];
	}	
	
	public static function getStatesOptions($countryid="")
	{
		$formData = JRequest::getVar('jform', array(), 'post', 'array');
		$options = array();
		$db = JFactory::getDbo();
		if((isset($countryid) && $countryid > 0) || (isset($formData['countryid']) && $formData['countryid'] > 0))
		{			
			if(isset($formData['countryid']) && $formData['countryid'] > 0)
			{
				$countryid = $formData['countryid'];
			}
			
			$query = $db->getQuery(true)
			->select('id As value, name As text')
			->from('#__state AS a')
			->where('a.state = 1')
			->where('a.countryid = '.$countryid)
			->order('a.name ASC');
			
			$db->setQuery($query);				
			try
			{
				$options = $db->loadObjectList();
			}
			catch (RuntimeException $e)
			{
				JError::raiseWarning(500, $e->getMessage());
			}
		}
		
		array_unshift($options, JHtml::_('select.option', '', JText::_('COM_LOCATIONMANAGEMENT_NO_STATE')));

		return $options;
			
	}
	//get country state from state table using country id
	public static function getCountryStates($id)
	{
		$options = array();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
			->select('id As value, name As text')
			->from('#__state AS a')
			->where('a.state = 1')
			->where('a.countryid = '.$id)
			->order('a.name ASC');
			
		// Get the options.
		$db->setQuery($query);

		try
		{
			$options = $db->loadObjectList();
		}
		catch (RuntimeException $e)
		{
			JError::raiseWarning(500, $e->getMessage());
		}

		return $options;
	}
	//get state city from city table using state id
	public static function getStatesCity($id)
	{
		$options = array();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
			->select('id As value, name As text')
			->from('#__city AS a')
			->where('a.state = 1')
			->where('a.stateid = '.$id)
			->order('a.name ASC');
		// Get the options.
		$db->setQuery($query);

		try
		{
			$options = $db->loadObjectList();
		}
		catch (RuntimeException $e)
		{
			JError::raiseWarning(500, $e->getMessage());
		}

		return $options;
	}
		//get city from city table
	public static function getCitiesOptions($stateid="")
	{
		
		$formData = JRequest::getVar('jform', array(), 'post', 'array');
		$options = array();
		$db = JFactory::getDbo();
		
		if((isset($stateid) && $stateid > 0) || (isset($formData['stateid']) && $formData['stateid'] > 0))
		{
			if(isset($formData['stateid']) && $formData['stateid'] > 0)
			{
				$stateid = $formData['stateid'];
			}
							
			$query = $db->getQuery(true)
			->select('id As value, name As text')
			->from('#__city AS a')
			->where('a.state = 1')
			->where('a.stateid = '.$stateid)
			->order('a.name ASC');
			
			// Get the options.
			$db->setQuery($query);
	
			try
			{
				$options = $db->loadObjectList();
			}
			catch (RuntimeException $e)
			{
				JError::raiseWarning(500, $e->getMessage());
			}
		}				
		array_unshift($options, JHtml::_('select.option', '', JText::_('COM_LOCATIONMANAGEMENT_NO_CITY')));
		return $options;
	}	
}
