<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
// No direct access.
defined('_JEXEC') or die;

require_once JPATH_COMPONENT . '/helpers/locationmanagement.php';

jimport('joomla.application.component.controllerform');
class LocationmanagementControllerAjax extends JControllerForm
{	
	public function getState()
	{
		$id = JRequest::getVar('id');
		$options = LocationmanagementHelper::getCountryStates($id);
		$data = "<option value=''>Select State</option>";	
		foreach ($options as $item) 
		{
			 $data .= "<option value='".$item->value."'>".$item->text."</option>";	
		}
		echo $data;
		exit();
	}
	
	public function getCity()
	{
		$id = JRequest::getVar('id');
		$options = LocationmanagementHelper::getStatesCity($id);
		$data = "<option value=''>Select City</option>";	
		foreach ($options as $item) 
		{
			 $data .= "<option value='".$item->value."'>".$item->text."</option>";	
		}
		echo $data;
		exit();
	}
	
}
