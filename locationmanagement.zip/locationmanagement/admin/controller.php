<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 *
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

defined('_JEXEC') or die;

/**
 * Locationmanagement master display controller.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 * @since       1.0
 */
class LocationmanagementController extends JControllerLegacy
{
	public function display($cachable = false, $urlparams = false)
	{
		require_once JPATH_COMPONENT . '/helpers/locationmanagement.php';
		$view		= JFactory::getApplication()->input->getCmd('view', 'countries');
        JFactory::getApplication()->input->set('view', $view);
		parent::display($cachable, $urlparams);
		return $this;
	}
}
