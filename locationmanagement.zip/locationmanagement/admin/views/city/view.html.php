<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

JLoader::register('LocationmanagementHelper', JPATH_COMPONENT . '/helpers/locationmanagement.php');

/**
 * View to edit a banner.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_locationmanagement
 * @since       1.5
 */
class LocationmanagementViewCity extends JViewLegacy
{
	protected $form;

	protected $item;

	protected $state;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 */
	public function display($tpl = null)
	{
		// Initialiase variables.
		$this->form		= $this->get('Form');
		$this->item		= $this->get('Item');
		$this->state	= $this->get('State');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			JError::raiseError(500, implode("\n", $errors));

			return false;
		}

		$this->addToolbar();
		JHtml::_('jquery.framework');
//		JHtml::_('script', 'media/com_locationmanagement/banner.js');
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	protected function addToolbar()
	{
		JFactory::getApplication()->input->set('hidemainmenu', true);

		$user		= JFactory::getUser();
		$userId		= $user->get('id');
		$isNew		= ($this->item->id == 0);
		//$checkedOut	= !($this->item->checked_out == 0 || $this->item->checked_out == $userId);

		// Since we don't track these assets at the item level, use the category id.
		$canDo		= JHelperContent::getActions('com_locationmanagement', 'city', $this->item->id);

		JToolbarHelper::title($isNew ? JText::_('COM_LOCATIONMANAGEMENT_MANAGER_CITY_NEW') : JText::_('COM_LOCATIONMANAGEMENT_MANAGER_CITY_EDIT'), 'bookmark banners');

		
		JToolbarHelper::apply('city.apply');
		JToolbarHelper::save('city.save');

		if ($canDo->get('core.create'))
		{
			JToolbarHelper::save2new('city.save2new');
		}
	

		// If an existing item, can save to a copy.
		if (!$isNew && $canDo->get('core.create'))
		{
			JToolbarHelper::save2copy('city.save2copy');
		}

		if (empty($this->item->id))
		{
			JToolbarHelper::cancel('city.cancel');
		}
		else
		{
			JToolbarHelper::cancel('city.cancel', 'JTOOLBAR_CLOSE');
		}

		JToolbarHelper::divider();
		JToolbarHelper::help('JHELP_COMPONENTS_LOCATIONMANAGEMENT_ATTRIBUTE_EDIT');
	}
}
